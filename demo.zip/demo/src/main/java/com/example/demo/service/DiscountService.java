package com.example.demo.service;

import java.util.List;

import com.example.demo.model.Discount;

public interface DiscountService {


List<Discount> getDiscountList();
	
	Discount getDiscountById(int id);
	
	void putDiscount(Discount discount);
	
	void updateDiscount(Discount discount);
	
	void deleteDiscount(int id);
}
