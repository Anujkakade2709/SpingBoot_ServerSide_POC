package com.example.demo.controller;

import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Orders;
import com.example.demo.service.OrdersServices;

@RestController 
public class OrdersControllers {
	
	@Autowired
	private OrdersServices service;
	
	@GetMapping("/orders")
	public List<Orders> list(){
		return service.listAll();
	}
	
	@GetMapping("/orders/{id}")
	public ResponseEntity<Orders> get(@PathVariable Integer id){
		try{
			Orders orders = service.get(id);
			return new ResponseEntity<Orders>(orders,HttpStatus.OK);
		}catch(NoSuchElementException e) {
			return new ResponseEntity<Orders>(HttpStatus.NOT_FOUND);
		}
	}
	
	@PostMapping("/orders")
	public void add(@RequestBody Orders orders){
		service.save(orders);
	}

	
	@PutMapping("/orders/{id}")
	public ResponseEntity<?> update(@RequestBody Orders orders,@PathVariable Integer id){
		try{
			Orders existorders = service.get(id);
			service.save(existorders);
			return new ResponseEntity<>(HttpStatus.OK);	
		}catch(NoSuchElementException e) {
			return new ResponseEntity<Orders>(HttpStatus.NOT_FOUND);
		}

	}

	
	@DeleteMapping("/orders/{id}")
	public void delete(@PathVariable Integer id){
		service.delete(id);
	}

	
	

}
