package com.example.demo.dao;

import java.util.List;

import com.example.demo.model.Product;

public interface ProductDao {

	List<Product> getProductList();
	
	Product getProductById(int id);
		
		void putProduct(Product product);
		
		void updateProduct(Product product);
		
		void deleteProduct(int id);
		
	
}
