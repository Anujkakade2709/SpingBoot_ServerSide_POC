package com.example.demo.dao;

import java.util.List;

import com.example.demo.model.Orders;

public interface OrdersDao {

List<Orders> getOrdersList();
	
	Orders getOrdersById(int id);
	
	void putOrders(Orders orders);
	
	void updateOrders(Orders orders);
	
	void deleteOrders(int id);
	
}
