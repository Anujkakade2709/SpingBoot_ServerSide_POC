package com.example.demo.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.demo.model.Category;
import com.example.demo.repo.CategoryRepository;

public class CategoryServices {

	@Autowired
    private CategoryRepository categoryrepository;
	
	public List<Category> listAll(){
		return categoryrepository.findAll();
	}
	
	public void save(Category category) {
		categoryrepository.save(category);
	}
	
	public Category get(Integer id) {
		return categoryrepository.findById(id).get();
	}
	
	public void delete(Integer id) {
		categoryrepository.deleteById(id);
	}
	
	
}
