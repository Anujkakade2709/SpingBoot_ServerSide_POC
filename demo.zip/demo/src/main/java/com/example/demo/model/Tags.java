package com.example.demo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="tags")
public class Tags {

	@Id
	@Column(name="tagid")
	int tag_id;
	@Column(name="productid")
	int product_id;
	@Column(name="tag")
	String tag_name;
	
	public int getTag_id() {
		return tag_id;
	}
	public void setTag_id(int tag_id) {
		this.tag_id = tag_id;
	}
	public int getProduct_id() {
		return product_id;
	}
	public void setProduct_id(int product_id) {
		this.product_id = product_id;
	}
	public String getTag_name() {
		return tag_name;
	}
	public void setTag_name(String tag_name) {
		this.tag_name = tag_name;
	}
	@Override
	public String toString() {
		return "Tags [tag_id=" + tag_id + ", product_id=" + product_id + ", tag_name=" + tag_name + "]";
	}
	
}
