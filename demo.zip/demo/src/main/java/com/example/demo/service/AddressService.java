package com.example.demo.service;

import java.util.List;

import com.example.demo.model.Item;

public interface AddressService {

	List<Item> getAddressList();
	
	Item getAddressById(int id);
	
	void putAddress(Item item);
	
	void updateAddress(Item item);
	
	void deleteAddress(int id);

}
