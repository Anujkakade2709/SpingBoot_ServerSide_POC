package com.example.demo.dao;

public class Product_detailsDaoImpl {

}
