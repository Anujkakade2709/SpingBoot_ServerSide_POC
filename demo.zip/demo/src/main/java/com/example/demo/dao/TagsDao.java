package com.example.demo.dao;

import java.util.List;

import com.example.demo.model.Tags;

public interface TagsDao {


List<Tags> getTagsList();
	
Tags getTagsById(int id);
		
		void putTags(Tags tags);
		
		void updateTags(Tags tags);
		
		void deleteTags(int id);
		
	
}
