package com.example.demo.service;

import java.util.List;

import com.example.demo.model.Orders;

public interface OrdersService {

List<Orders> getOrdersList();
	
	Orders getOrdersById(int id);
	
	void putOrders(Orders orders);
	
	void updateOrders(Orders orders);
	
	void deleteOrders(int id);
}
