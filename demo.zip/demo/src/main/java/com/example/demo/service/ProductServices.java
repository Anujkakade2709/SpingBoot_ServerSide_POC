package com.example.demo.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.demo.model.Product;
import com.example.demo.repo.ProductRepository;

public class ProductServices {

	@Autowired
    private ProductRepository productrepository;
	
	public List<Product> listAll(){
		return productrepository.findAll();
	}
	
	public void save(Product product) {
		productrepository.save(product);
	}
	
	public Product get(Integer id) {
		return productrepository.findById(id).get();
	}
	
	public void delete(Integer id) {
		productrepository.deleteById(id);
	}
	
	
}
