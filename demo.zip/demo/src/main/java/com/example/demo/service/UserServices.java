package com.example.demo.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.demo.model.User;
import com.example.demo.repo.UserRepository;

public class UserServices {

	@Autowired
    private UserRepository userrepository;
	
	public List<User> listAll(){
		return userrepository.findAll();
	}
	
	public void save(User user) {
		userrepository.save(user);
	}
	
	public User get(Integer id) {
		return userrepository.findById(id).get();
	}
	
	public void delete(Integer id) {
		userrepository.deleteById(id);
	}
	
	
}
