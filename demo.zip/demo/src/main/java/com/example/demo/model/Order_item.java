package com.example.demo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Orderitem")
public class Order_item {

	@Id
	@Column(name="orderitemid")
	int order_item_id;
	@Column(name="orderid")
	int order_id;
	@Column
	int quantity;
	@Column(name="productdetailsid")
	int product_details_id;
	
	public int getOrder_item_id() {
		return order_item_id;
	}
	public void setOrder_item_id(int order_item_id) {
		this.order_item_id = order_item_id;
	}
	public int getOrder_id() {
		return order_id;
	}
	public void setOrder_id(int order_id) {
		this.order_id = order_id;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public int getProduct_details_id() {
		return product_details_id;
	}
	public void setProduct_details(int product_details_id) {
		this.product_details_id = product_details_id;
	}
	@Override
	public String toString() {
		return "Order_item [order_item_id=" + order_item_id + ", order_id=" + order_id + ", quantity=" + quantity
				+ ", product_details_id=" + product_details_id + "]";
	}
	
	
	
	
	
}
