package com.example.demo.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.demo.model.Item;
import com.example.demo.repo.ItemRepository;

public class ItemServices {

	@Autowired
    private ItemRepository itemrepository;
	
	public List<Item> listAll(){
		return itemrepository.findAll();
	}
	
	public void save(Item item) {
		itemrepository.save(item);
	}
	
	public Item get(Integer id) {
		return itemrepository.findById(id).get();
	}
	
	public void delete(Integer id) {
		itemrepository.deleteById(id);
	}
	
	
}
