package com.example.demo.controller;

import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Address;
import com.example.demo.service.AddressServices;

@RestController 
public class AddressControllers {
	
	@Autowired
	private AddressServices service;
	
	@GetMapping("/addresses")
	public List<Address> list(){
		return service.listAll();
	}
	
	@GetMapping("/addresses/{id}")
	public ResponseEntity<Address> get(@PathVariable Integer id){
		try{
			Address address = service.get(id);
			return new ResponseEntity<Address>(address,HttpStatus.OK);
		}catch(NoSuchElementException e) {
			return new ResponseEntity<Address>(HttpStatus.NOT_FOUND);
		}
	}
	
	@PostMapping("/addresses")
	public void add(@RequestBody Address address){
		service.save(address);
	}

	
	@PutMapping("/addresses/{id}")
	public ResponseEntity<?> update(@RequestBody Address address,@PathVariable Integer id){
		try{
			Address existaddress = service.get(id);
			service.save(existaddress);
			return new ResponseEntity<>(HttpStatus.OK);	
		}catch(NoSuchElementException e) {
			return new ResponseEntity<Address>(HttpStatus.NOT_FOUND);
		}

	}

	
	@DeleteMapping("/addresses/{id}")
	public void delete(@PathVariable Integer id){
		service.delete(id);
	}

	
	

}
