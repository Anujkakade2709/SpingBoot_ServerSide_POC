package com.example.demo.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.demo.model.Order_item;
import com.example.demo.repo.Order_ItemRepository;

public class Order_itemServices {

	@Autowired
    private Order_ItemRepository Order_itemrepository;
	
	public List<Order_item> listAll(){
		return Order_itemrepository.findAll();
	}
	
	public void save(Order_item order_item) {
		Order_itemrepository.save(order_item);
	}
	
	public Order_item get(Integer id) {
		return Order_itemrepository.findById(id).get();
	}
	
	public void delete(Integer id) {
		Order_itemrepository.deleteById(id);
	}
	
	
}
