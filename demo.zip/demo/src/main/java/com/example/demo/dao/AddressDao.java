package com.example.demo.dao;

import java.util.List;

import com.example.demo.model.Item;

public interface AddressDao {
	
	List<Item> getAddressList();
	
	Item getAddressById(int id);
	
	void putAddress(Item item);
	
	void updateAddress(Item item);
	
	void deleteAddress(int id);

}
