package com.example.demo.dao;

import java.util.List;

import com.example.demo.model.product_details;

public interface Product_detailsDao {

List<product_details> getProduct_detailsList();
	
product_details getProduct_detailsById(int id);
	
	void putProduct_details(product_details products_details);
	
	void updateProduct_details(product_details products_details);
	
	void deleteProduct_details(int id);
	
}
