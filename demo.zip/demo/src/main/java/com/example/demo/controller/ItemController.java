package com.example.demo.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Item;
import com.example.demo.service.ItemService;

@RestController
@RequestMapping("/api")
public class ItemController {
	
	@Autowired
	private ItemService itemService;
	
	@GetMapping("/item")
	public List<Item> get(){
		return itemService.getItemList();
	}

	@PostMapping("/item")
	public Item save(@RequestBody Item itemObj){
		itemService.updateItem(itemObj);
		return itemObj;
	}
	
	@GetMapping("/item/{id}")
	public Item get(@PathVariable int id) throws Exception {
		Item itemObj =  itemService.getItemById(id);
		if(itemObj == null) {
			throw new Exception("Item with id "+id+" not found");
		}
		return itemObj;
	}
	
	@DeleteMapping("/item/{id}")
	public String delete(@PathVariable int id) {
		itemService.deleteItem(id);
		return "Item has been deleted with id :" +id;
		
	}
	
	@PutMapping("/item")
	public Item update(@RequestBody Item itemObj) {
		itemService.updateItem(itemObj);
		return itemObj;
	}
}
