package com.example.demo.controller;

import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.product_details;
import com.example.demo.service.Product_detailsServices;

@RestController 
public class product_detailsControllers {
	
	@Autowired
	private Product_detailsServices service;
	
	@GetMapping("/product_details")
	public List<product_details> list(){
		return service.listAll();
	}
	
	@GetMapping("/product_details/{id}")
	public ResponseEntity<product_details> get(@PathVariable Integer id){
		try{
			product_details pd = service.get(id);
			return new ResponseEntity<product_details>(pd,HttpStatus.OK);
		}catch(NoSuchElementException e) {
			return new ResponseEntity<product_details>(HttpStatus.NOT_FOUND);
		}
	}
	
	@PostMapping("/product_details")
	public void add(@RequestBody product_details pd){
		service.save(pd);
	}

	
	@PutMapping("/product_details/{id}")
	public ResponseEntity<?> update(@RequestBody product_details pd,@PathVariable Integer id){
		try{
			product_details existproduct_details = service.get(id);
			service.save(existproduct_details);
			return new ResponseEntity<>(HttpStatus.OK);	
		}catch(NoSuchElementException e) {
			return new ResponseEntity<product_details>(HttpStatus.NOT_FOUND);
		}

	}

	
	@DeleteMapping("/product_details/{id}")
	public void delete(@PathVariable Integer id){
		service.delete(id);
	}

	
	

}
