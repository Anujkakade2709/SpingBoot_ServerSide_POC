package com.example.demo.service;

import java.util.List;

import com.example.demo.model.Category;

public interface CategoryService {

List<Category> getCategoryList();
	
	Category getCategoryById(int id);
	
	void putCategory(Category category);
	
	void updateCategory(Category category);
	
	void deleteCategory(int id);
}
