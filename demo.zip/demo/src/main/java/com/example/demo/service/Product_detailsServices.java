package com.example.demo.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.demo.model.product_details;
import com.example.demo.repo.product_detailsRepository;

public class Product_detailsServices {

	@Autowired
    private product_detailsRepository pdrepository;
	
	public List<product_details> listAll(){
		return pdrepository.findAll();
	}
	
	public void save(product_details pd) {
		pdrepository.save(pd);
	}
	
	public product_details get(Integer id) {
		return pdrepository.findById(id).get();
	}
	
	public void delete(Integer id) {
		pdrepository.deleteById(id);
	}
	
	
}
