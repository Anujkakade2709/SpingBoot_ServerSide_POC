package com.example.demo.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.demo.model.Tags;
import com.example.demo.repo.TagsRepository;

public class TagsServices {

	@Autowired
    private TagsRepository tagsrepository;
	
	public List<Tags> listAll(){
		return tagsrepository.findAll();
	}
	
	public void save(Tags tags) {
		tagsrepository.save(tags);
	}
	
	public Tags get(Integer id) {
		return tagsrepository.findById(id).get();
	}
	
	public void delete(Integer id) {
		tagsrepository.deleteById(id);
	}
	
	
}
