package com.example.demo.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.demo.model.Discount;
import com.example.demo.repo.DiscountRepository;

public class DiscountServices {

	@Autowired
    private DiscountRepository discountrepository;
	
	public List<Discount> listAll(){
		return discountrepository.findAll();
	}
	
	public void save(Discount discount) {
		discountrepository.save(discount);
	}
	
	public Discount get(Integer id) {
		return discountrepository.findById(id).get();
	}
	
	public void delete(Integer id) {
		discountrepository.deleteById(id);
	}
	
	
}
