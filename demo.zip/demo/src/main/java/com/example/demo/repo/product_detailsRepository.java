package com.example.demo.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.model.product_details;

public interface product_detailsRepository extends JpaRepository<product_details,Integer>{

}
