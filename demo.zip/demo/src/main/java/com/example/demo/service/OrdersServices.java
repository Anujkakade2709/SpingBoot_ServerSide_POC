package com.example.demo.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.demo.model.Orders;
import com.example.demo.repo.OrdersRepository;

public class OrdersServices {

	@Autowired
    private OrdersRepository Ordersrepository;
	
	public List<Orders> listAll(){
		return Ordersrepository.findAll();
	}
	
	public void save(Orders orders) {
		Ordersrepository.save(orders);
	}
	
	public Orders get(Integer id) {
		return Ordersrepository.findById(id).get();
	}
	
	public void delete(Integer id) {
		Ordersrepository.deleteById(id);
	}
	
	
}
