package com.example.demo.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.demo.model.Address;
import com.example.demo.repo.AddressRepository;

public class AddressServices {

	@Autowired
    private AddressRepository addressrepository;
	
	public List<Address> listAll(){
		return addressrepository.findAll();
	}
	
	public void save(Address address) {
		addressrepository.save(address);
	}
	
	public Address get(Integer id) {
		return addressrepository.findById(id).get();
	}
	
	public void delete(Integer id) {
		addressrepository.deleteById(id);
	}
	
	
}
