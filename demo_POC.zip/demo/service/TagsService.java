package com.example.demo.service;

import java.util.List;

import com.example.demo.model.Tags;

public interface TagsService {


List<Tags> getTagsList();
	
Tags getTagsById(int id);
		
		void putTags(Tags tags);
		
		void updateTags(Tags tags);
		
		void deleteTags(int id);
}
