package com.example.demo.service;

import java.util.List;

import com.example.demo.model.product_details;

public interface Product_detailsService {


List<product_details> getProduct_detailsList();
	
product_details getProduct_detailsById(int id);
	
	void putProduct_details(product_details products_details);
	
	void updateProduct_details(product_details products_details);
	
	void deleteProduct_details(int id);
}
