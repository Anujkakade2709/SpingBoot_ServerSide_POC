package com.example.demo.service;

import java.util.List;

import com.example.demo.model.Item;

public interface ItemService {

	
	List<Item> getItemList();
	
	Item getItemById(int id);
	
	void putItem(Item item);
	
	void updateItem(Item item);
	
	void deleteItem(int id);

}
