package com.example.demo.service;

import java.util.List;

import com.example.demo.model.Item;

public class AddressServiceImpl implements AddressService{

	@Override
	public List<Item> getAddressList() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Item getAddressById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void putAddress(Item item) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateAddress(Item item) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteAddress(int id) {
		// TODO Auto-generated method stub
		
	}

}
