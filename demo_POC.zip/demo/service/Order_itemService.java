package com.example.demo.service;

import java.util.List;

import com.example.demo.model.Order_item;

public interface Order_itemService {


List<Order_item> getOrder_itemList();
	
	Order_item getOrder_itemById(int id);
	
	void putOrder_item(Order_item order_item);
	
	void updateOrder_item(Order_item order_item);
	
	void deleteOrder_item(int id);
}
