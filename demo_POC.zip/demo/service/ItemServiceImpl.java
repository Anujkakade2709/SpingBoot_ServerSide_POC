package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.dao.ItemDao;
import com.example.demo.model.Item;

@Service
public class ItemServiceImpl implements ItemService{
	
	@Autowired
	private ItemDao itemDao;

	@Transactional
	@Override
	public List<Item> getItemList() {
		return itemDao.getItemList();
	}

	@Transactional
	@Override
	public Item getItemById(int id) {
		return itemDao.getItemById(id);
	}

	@Transactional
	@Override
	public void putItem(Item item) {
		// TODO Auto-generated method stub
		
	}

	@Transactional
	@Override
	public void updateItem(Item item) {
		itemDao.updateItem(item);
		
	}

	@Transactional
	@Override
	public void deleteItem(int id) {
		// TODO Auto-generated method stub
		itemDao.deleteItem(id);
	}

}
