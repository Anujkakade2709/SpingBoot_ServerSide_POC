package com.example.demo.controller;

public class product_detailsController {

}
