package com.example.demo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Productdetails")
public class product_details {
	
	@Id
	@Column(name="productdetailsid")
	int product_detail_id;
	@Column(name="productid")
	int product_id;
	@Column
	int size;
	@Column
	String color;
	
	public int getProduct_detail_id() {
		return product_detail_id;
	}
	public void setProduct_detail_id(int product_detail_id) {
		this.product_detail_id = product_detail_id;
	}
	public int getProduct_id() {
		return product_id;
	}
	public void setProduct_id(int product_id) {
		this.product_id = product_id;
	}
	public int getSize() {
		return size;
	}
	public void setSize(int size) {
		this.size = size;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	@Override
	public String toString() {
		return "product_details [product_detail_id=" + product_detail_id + ", product_id=" + product_id + ", size="
				+ size + ", color=" + color + "]";
	}
	
	
	

}
