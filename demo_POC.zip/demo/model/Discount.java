package com.example.demo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Discount")
public class Discount {

	@Id
	@Column(name="discountid")
	int id;
	@Column(name="discountname")
	String name;
	@Column(name="discounttype")
	String type;
	@Column(name="valid")
	String validity;
	@Column
	int quantity;
	@Column
	String created;
	@Column(name="addressid")
	int addressid;      
	
	public String getCreated() {
		return created;
	}
	public void setCreated(String created) {
		this.created = created;
	}
	public int getAddressid() {
		return addressid;
	}
	public void setAddressid(int addressid) {
		this.addressid = addressid;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getValidity() {
		return validity;
	}
	public void setValidity(String validity) {
		this.validity = validity;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	@Override
	public String toString() {
		return "Discount [id=" + id + ", name=" + name + ", type=" + type + ", validity=" + validity + ", quantity="
				+ quantity + ", created=" + created + ", addressid=" + addressid + "]";
	}
	
	
	
}
