package com.example.demo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Useraddress")
public class Address {
	
	@Id
	@Column(name="addressid")
	int address_id;
	@Column(name="userid")
	int user_id;
	@Column(name="postcode")
	int pincode;
	@Column(name="addresslines")
	String addressline;
	@Column
	String city;
	@Column
	int phone;
	public int getAddress_id() {
		return address_id;
	}
	public void setAddress_id(int address_id) {
		this.address_id = address_id;
	}
	public int getUser_id() {
		return user_id;
	}
	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}
	public int getPincode() {
		return pincode;
	}
	public void setPincode(int pincode) {
		this.pincode = pincode;
	}
	public String getAddressline() {
		return addressline;
	}
	public void setAddressline(String addressline) {
		this.addressline = addressline;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public int getPhone() {
		return phone;
	}
	public void setPhone(int phone) {
		this.phone = phone;
	}
	@Override
	public String toString() {
		return "Address [address_id=" + address_id + ", user_id=" + user_id + ", pincode=" + pincode + ", addressline="
				+ addressline + ", city=" + city + ", phone=" + phone + "]";
	}
	
	
	
	
	

}
