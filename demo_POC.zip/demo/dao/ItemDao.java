package com.example.demo.dao;
import com.example.demo.model.Item;
import java.util.List;


public interface ItemDao {
	
	
	List<Item> getItemList();
	
	Item getItemById(int id);
	
	void putItem(Item item);
	
	void updateItem(Item item);
	
	void deleteItem(int id);

}
