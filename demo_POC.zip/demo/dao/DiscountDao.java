package com.example.demo.dao;

import java.util.List;

import com.example.demo.model.Discount;

public interface DiscountDao {

List<Discount> getDiscountList();
	
	Discount getDiscountById(int id);
	
	void putDiscount(Discount discount);
	
	void updateDiscount(Discount discount);
	
	void deleteDiscount(int id);
	
}
