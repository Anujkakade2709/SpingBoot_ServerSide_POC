package com.example.demo.dao;

import java.util.List;

import com.example.demo.model.Category;

public interface CategoryDao {

List<Category> getCategoryList();
	
	Category getCategoryById(int id);
	
	void putCategory(Category category);
	
	void updateCategory(Category category);
	
	void deleteCategory(int id);
}
