package com.example.demo.dao;

import java.util.List;

import com.example.demo.model.User;

public interface UserDao {

List<User> getUserList();
	
	User getUserById(int id);
		
		void putUser(User user);
		
		void updateUser(User user);
		
		void deleteUser(int id);
		
	
	
}
