package com.example.demo.dao;

import java.util.List;

import javax.persistence.EntityManager;

import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.demo.model.Item;

@Repository
public class ItemDaoImpl implements ItemDao {
	
	@Autowired
	private EntityManager entityManager;

	@Override
	public List<Item> getItemList() {
		Session currentSession = entityManager.unwrap(Session.class);
		Query<Item> query = currentSession.createQuery("from Cart_item",Item.class);
		List<Item> itemList = query.getResultList();
		return itemList;
	}

	@Override
	public Item getItemById(int id) {
		Session currentSession = entityManager.unwrap(Session.class);
		Item itemObj = currentSession.get(Item.class,id);
		return itemObj;
	}

	@Override
	public void putItem(Item item) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateItem(Item item) {
		Session currentSession = entityManager.unwrap(Session.class);
		currentSession.saveOrUpdate(item);		
	}

	@Override
	public void deleteItem(int id) {
		// TODO Auto-generated method stub
		Session currentSession = entityManager.unwrap(Session.class);
		Item itemObj = currentSession.get(Item.class,id);
		currentSession.delete(itemObj);
	}

}
