package com.example.demo.dao;

import java.util.List;

import com.example.demo.model.Order_item;

public interface Order_itemDao {

List<Order_item> getOrder_itemList();
	
	Order_item getOrder_itemById(int id);
	
	void putOrder_item(Order_item order_item);
	
	void updateOrder_item(Order_item order_item);
	
	void deleteOrder_item(int id);
}
